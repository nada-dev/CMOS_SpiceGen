#pragma once
class MOSFET
{
public:





private:
};

